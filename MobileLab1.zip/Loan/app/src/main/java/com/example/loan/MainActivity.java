package com.example.loan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


       EditText editTextNumber = (EditText) findViewById(R.id.editTextNumber);
       EditText editLoanAmount = (EditText) findViewById(R.id.editLoanAmount);
       EditText editInterestRate = (EditText) findViewById(R.id.editInterestRate);
       Button buttonCalculate = (Button) findViewById(R.id.buttonCalculate);
       buttonCalculate.setOnClickListener(
               view -> {
                   Intent intent = new Intent(MainActivity.this, DisplayPament.class);
                   int intNumberYwr = Integer.parseInt(editTextNumber.getText().toString());
                   int intLoanAmount = Integer.parseInt(editLoanAmount.getText().toString());
                   float decInterestRate = Float.parseFloat(editInterestRate.getText().toString());
                   float dectopercent = decInterestRate/1200;
                   float totalmonths = intNumberYwr * 12;
                   float decMonthlyPayment;
                           decMonthlyPayment = (float) ((intLoanAmount * dectopercent * Math.pow(1 + dectopercent,totalmonths ))/ (Math.pow(1 + dectopercent, totalmonths) - 1 ));
                   intent.putExtra("Totalvalue", decMonthlyPayment);
                    startActivity(intent);

               });
    }






}