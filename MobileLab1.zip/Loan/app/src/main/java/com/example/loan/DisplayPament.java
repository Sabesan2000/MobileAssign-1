package com.example.loan;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.text.BreakIterator;
import java.text.DecimalFormat;

public class DisplayPament extends AppCompatActivity {

    private float TotalAmount;


    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_pament);

        TextView displayAnswer = (TextView) findViewById(R.id.DisplayAnswer);

        Bundle a = getIntent().getExtras();
       if (a != null) {
            TotalAmount = a.getFloat("Totalvalue");
        Intent intent = getIntent();
        }
        DecimalFormat decimalFormat = new DecimalFormat("$###,###.##");
        displayAnswer.setText("Monthly Payment is " + String.valueOf(decimalFormat.format(TotalAmount)));

    }
}